package com.voicecontrol.app

import android.app.KeyguardManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import java.time.LocalDate
import java.time.temporal.ChronoUnit

object Security {
    private val risky = setOf(
        "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS",
        "android.permission.RECORD_AUDIO", "android.permission.CAMERA", "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG",
        "android.permission.SYSTEM_ALERT_WINDOW", "android.permission.REQUEST_INSTALL_PACKAGES"
    )

    fun scan(c: Context): String {
        var score = 100
        val sb = StringBuilder("🛡 تقرير الفحص الأمني\n\n")
        val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isDeviceSecure) sb.append("✓ قفل الشاشة مفعّل\n") else { score -= 20; sb.append("✗ لا يوجد قفل شاشة آمن (-20)\n") }

        if (Settings.Global.getInt(c.contentResolver, "adb_enabled", 0) == 1) { score -= 10; sb.append("✗ تصحيح USB (ADB) مفعّل (-10)\n") } else sb.append("✓ ADB معطّل\n")

        try {
            val days = ChronoUnit.DAYS.between(LocalDate.parse(Build.VERSION.SECURITY_PATCH), LocalDate.now())
            if (days > 180) { score -= 15; sb.append("✗ تحديث الأمان قديم: ${Build.VERSION.SECURITY_PATCH} (-15)\n") }
            else sb.append("✓ تحديث الأمان: ${Build.VERSION.SECURITY_PATCH}\n")
        } catch (e: Exception) { sb.append("؟ تعذّر قراءة تاريخ تحديث الأمان\n") }

        val acc = (Settings.Secure.getString(c.contentResolver, "enabled_accessibility_services") ?: "")
            .split(":").filter { it.isNotBlank() && !it.contains(c.packageName) }
        if (acc.isNotEmpty()) {
            score -= minOf(15, acc.size * 5)
            sb.append("⚠ خدمات وصول أخرى مفعّلة (تستطيع قراءة الشاشة):\n")
            acc.forEach { sb.append("   • ").append(it.substringBefore('/')).append('\n') }
        } else sb.append("✓ لا توجد خدمات وصول مريبة أخرى\n")

        try {
            val pm = c.packageManager
            val heavy = ArrayList<String>()
            var side = 0
            for (p in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
                val ai = p.applicationInfo ?: continue
                if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || p.packageName == c.packageName) continue
                val n = (p.requestedPermissions ?: emptyArray()).count { it in risky }
                if (n >= 4) heavy.add("${pm.getApplicationLabel(ai)} ($n)")
                val inst = if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName
                else @Suppress("DEPRECATION") pm.getInstallerPackageName(p.packageName)
                if (inst == null) side++
            }
            if (side > 5) { score -= 10; sb.append("⚠ تطبيقات مثبّتة من خارج المتاجر: $side (-10)\n") }
            else sb.append("✓ تطبيقات من خارج المتاجر: $side\n")
            if (heavy.isNotEmpty()) {
                score -= minOf(15, heavy.size * 3)
                sb.append("⚠ تطبيقات بصلاحيات حساسة كثيرة:\n")
                heavy.take(8).forEach { sb.append("   • ").append(it).append('\n') }
            }
        } catch (e: Exception) { sb.append("؟ تعذّر فحص التطبيقات\n") }

        score = score.coerceAtLeast(0)
        val r = when { score >= 85 -> "ممتاز"; score >= 65 -> "جيد"; score >= 40 -> "متوسط" else -> "ضعيف" }
        sb.append("\nالنتيجة: $score/100 — $r")
        return sb.toString()
    }
}
