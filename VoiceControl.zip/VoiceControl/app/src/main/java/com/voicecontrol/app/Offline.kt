package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Offline {
    private var torchOn = false

    fun norm(s: String): String {
        var t = s.lowercase().trim()
        "٠١٢٣٤٥٦٧٨٩".forEachIndexed { i, c -> t = t.replace(c, '0' + i) }
        t = t.replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')
        for (f in listOf("لو سمحت", "من فضلك", "يا مساعد", "please")) t = t.replace(f, "")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun has(n: String, vararg w: String): Boolean = w.any {
        val k = norm(it)
        if (k.all { c -> c.code < 128 }) (" $n ").contains(" $k ") else n.contains(k)
    }

    private fun num(n: String): Int? = Regex("\\d+").find(n)?.value?.toIntOrNull()

    private fun launch(svc: ControlService, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); svc.startActivity(i); true
    } catch (e: Exception) { false }

    private fun done(s: ControlService, m: String): String { s.mood(Mood.HAPPY); s.speak(m); return "✓ $m" }

    private val pages: List<Pair<List<String>, String>> = listOf(
        listOf("واي فاي", "wifi", "wi-fi", "الانترنت") to "android.settings.WIFI_SETTINGS",
        listOf("بلوتوث", "bluetooth") to "android.settings.BLUETOOTH_SETTINGS",
        listOf("وضع الطيران", "airplane", "طيران") to "android.settings.AIRPLANE_MODE_SETTINGS",
        listOf("الشاشه", "العرض", "السطوع", "الوضع الليلي", "brightness", "display", "dark mode") to "android.settings.DISPLAY_SETTINGS",
        listOf("الصوت", "النغمه", "عدم الازعاج", "sound", "ringtone", "do not disturb") to "android.settings.SOUND_SETTINGS",
        listOf("توفير الطاقه", "battery saver", "البطاريه", "battery") to "android.settings.BATTERY_SAVER_SETTINGS",
        listOf("التخزين", "storage") to "android.settings.INTERNAL_STORAGE_SETTINGS",
        listOf("التطبيقات", "ادارة التطبيقات", "apps") to "android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS",
        listOf("الموقع", "gps", "location") to "android.settings.LOCATION_SOURCE_SETTINGS",
        listOf("الامان", "الحمايه", "security") to "android.settings.SECURITY_SETTINGS",
        listOf("اللغه", "language") to "android.settings.LOCALE_SETTINGS",
        listOf("التاريخ والوقت", "الوقت والتاريخ", "date and time") to "android.settings.DATE_SETTINGS",
        listOf("امكانيه الوصول", "accessibility") to "android.settings.ACCESSIBILITY_SETTINGS",
        listOf("خيارات المطور", "المطور", "developer") to "android.settings.APPLICATION_DEVELOPMENT_SETTINGS",
        listOf("nfc", "الدفع") to "android.settings.NFC_SETTINGS",
        listOf("البيانات", "التجوال", "data", "roaming") to "android.settings.DATA_ROAMING_SETTINGS",
        listOf("الشبكه", "الشبكات", "network", "hotspot", "نقطه الاتصال") to "android.settings.WIRELESS_SETTINGS",
        listOf("الخصوصيه", "privacy") to "android.settings.PRIVACY_SETTINGS",
        listOf("لوحه المفاتيح", "keyboard") to "android.settings.INPUT_METHOD_SETTINGS",
        listOf("البث", "cast", "mirror") to "android.settings.CAST_SETTINGS",
        listOf("عن الهاتف", "حول الهاتف", "about phone") to "android.settings.DEVICE_INFO_SETTINGS",
        listOf("وقت الشاشه", "usage access", "الاستخدام") to "android.settings.USAGE_ACCESS_SETTINGS",
        listOf("الاشعارات", "notification access") to "android.settings.NOTIFICATION_LISTENER_SETTINGS",
        listOf("المزامنه", "الحسابات", "sync", "accounts") to "android.settings.SYNC_SETTINGS",
        listOf("اعدادات", "الاعدادات", "settings") to "android.settings.SETTINGS"
    )

    private val alias = mapOf(
        "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "واتس" to "whatsapp", "يوتيوب" to "youtube",
        "فيسبوك" to "facebook", "فيس بوك" to "facebook", "تيك توك" to "tiktok", "انستغرام" to "instagram",
        "انستقرام" to "instagram", "انستا" to "instagram", "تلغرام" to "telegram", "تيليجرام" to "telegram",
        "تليجرام" to "telegram", "سناب شات" to "snapchat", "سناب" to "snapchat", "كروم" to "chrome",
        "جيميل" to "gmail", "الخرائط" to "maps", "خرائط" to "maps", "الصور" to "photos", "المعرض" to "gallery",
        "الحاسبه" to "calculator", "الساعه" to "clock", "التقويم" to "calendar", "الملفات" to "files",
        "المتجر" to "play store", "بلاي ستور" to "play store", "الهاتف" to "phone", "الرسائل" to "messages",
        "الكاميرا" to "camera", "الاعدادات" to "settings", "تويتر" to "x", "نتفلكس" to "netflix",
        "سبوتيفاي" to "spotify", "زوم" to "zoom", "ماسنجر" to "messenger", "ميسنجر" to "messenger",
        "جوجل" to "google", "قوقل" to "google", "ملاحظات" to "notes", "جهات الاتصال" to "contacts",
        "ديسكورد" to "discord", "سكايب" to "skype", "لينكد ان" to "linkedin", "امازون" to "amazon", "اوبر" to "uber"
    )

    private fun torch(svc: ControlService, st: Boolean?): String {
        val cm = svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "✗ لا يوجد فلاش"
        val v = st ?: !torchOn
        cm.setTorchMode(id, v)
        torchOn = v
        return done(svc, if (v) "شغلت الكشاف" else "أطفأت الكشاف")
    }

    private fun volume(svc: ControlService, n: String): String? {
        val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = if (has(n, "الرنين", "ring")) AudioManager.STREAM_RING else AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(st)
        val p = num(n)
        when {
            has(n, "كتم", "صامت", "mute") -> am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            has(n, "اقصي", "اعلي مستوي", "max", "كامل") -> am.setStreamVolume(st, max, AudioManager.FLAG_SHOW_UI)
            p != null -> am.setStreamVolume(st, p.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI)
            has(n, "ارفع", "زيد", "علي", "up", "louder", "higher") -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            has(n, "اخفض", "نزل", "قلل", "down", "lower", "quieter") -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            else -> return null
        }
        return done(svc, "تم ضبط الصوت")
    }

    private fun media(svc: ControlService, code: Int, msg: String): String {
        val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return done(svc, msg)
    }

    private fun focused(svc: ControlService): AccessibilityNodeInfo? =
        svc.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

    private fun nodeAct(svc: ControlService, a: Int, msg: String): String {
        val n = focused(svc) ?: return "✗ لا يوجد حقل نص نشط"
        return if (n.performAction(a)) done(svc, msg) else "✗ تعذّر التنفيذ"
    }

    fun help(): String = "أوامر بدون إنترنت (صيغ كثيرة لكل أمر):\n" +
        "• افتح/شغل أي تطبيق (أسماء عربية وإنجليزية)\n• الكشاف: شغل/أطفئ\n• الصوت: ارفع، اخفض، كتم، اضبط 40، الرنين\n" +
        "• الموسيقى: التالي، السابق، إيقاف مؤقت، شغل الموسيقى\n• أكثر من 25 صفحة إعدادات (واي فاي، بلوتوث، بطارية …)\n" +
        "• الكاميرا/فيديو • اتصل 0123… • ابحث عن … • يوتيوب ابحث عن … • خذني إلى …\n• منبه الساعة 7:30 • مؤقت 5 دقائق\n" +
        "• كم الساعة؟ التاريخ؟ كم البطارية؟ المساحة؟ اسم الجهاز؟\n• اسحب لليسار/اليمين/فوق/تحت • اضغط في المنتصف • اضغط مطولاً\n" +
        "• انسخ، الصق، قص، حدد الكل، امسح النص\n• الإعدادات السريعة، قائمة الطاقة، تقسيم الشاشة، اقفل الشاشة"

    fun run(svc: ControlService, raw: String): String? {
        val n = norm(raw)
        if (n.isEmpty()) return null
        val on = has(n, "شغل", "افتح", "فعل", "on", "اضوي", "start")
        val off = has(n, "اطفي", "اغلق", "وقف", "off", "عطل", "stop")

        if (has(n, "الاوامر", "مساعده", "help", "commands")) return help()
        if (has(n, "كشاف", "فلاش", "torch", "flashlight")) return torch(svc, if (off) false else if (on) true else null)
        if (has(n, "الصوت", "صوت", "volume", "الرنين", "ring")) volume(svc, n)?.let { return it }

        if (has(n, "التالي", "next song", "skip song")) return media(svc, KeyEvent.KEYCODE_MEDIA_NEXT, "التالي")
        if (has(n, "السابق", "previous song")) return media(svc, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "السابق")
        if (has(n, "ايقاف مؤقت", "pause", "وقف الموسيقي", "stop music")) return media(svc, KeyEvent.KEYCODE_MEDIA_PAUSE, "إيقاف مؤقت")
        if (has(n, "شغل الموسيقي", "play music", "استئناف", "resume music")) return media(svc, KeyEvent.KEYCODE_MEDIA_PLAY, "تشغيل")

        if (has(n, "كم الساعه", "الوقت الان", "what time", "time now")) {
            return done(svc, "الساعة الآن " + SimpleDateFormat("hh:mm a", Locale("ar")).format(Date()))
        }
        if (has(n, "التاريخ", "اي يوم", "what date", "today date")) {
            return done(svc, SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar")).format(Date()))
        }
        if (has(n, "كم البطاريه", "نسبه البطاريه", "battery level", "battery percent")) {
            val i = svc.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val ch = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
            return done(svc, "البطارية ${l * 100 / s}%" + if (ch) " وتشحن" else "")
        }
        if (has(n, "المساحه المتبقيه", "كم المساحه", "free space")) {
            val st = StatFs(Environment.getDataDirectory().path)
            return done(svc, "المساحة المتبقية %.1f جيجابايت".format(st.availableBytes / 1e9))
        }
        if (has(n, "اسم الجهاز", "موديل الجهاز", "device model")) return done(svc, "${Build.MANUFACTURER} ${Build.MODEL}")
        if (has(n, "نسخه الاندرويد", "android version")) return done(svc, "أندرويد ${Build.VERSION.RELEASE}")

        if (has(n, "اقفل الشاشه", "اطفي الشاشه", "lock screen", "turn off screen")) { svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); return done(svc, "قفلت الشاشة") }
        if (has(n, "الاعدادات السريعه", "quick settings")) { svc.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS); return done(svc, "الإعدادات السريعة") }
        if (has(n, "قائمه الطاقه", "power menu")) { svc.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG); return done(svc, "قائمة الطاقة") }
        if (has(n, "تقسيم الشاشه", "split screen")) { svc.global(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN); return done(svc, "تقسيم الشاشة") }

        val dm = svc.resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        if (has(n, "اسحب", "swipe")) {
            val ok = when {
                has(n, "يسار", "left") -> svc.gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
                has(n, "يمين", "right") -> svc.gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
                has(n, "فوق", "اعلي", "up") -> svc.gesture(w / 2, h * 0.75f, w / 2, h * 0.25f, 300)
                has(n, "تحت", "اسفل", "down") -> svc.gesture(w / 2, h * 0.25f, w / 2, h * 0.75f, 300)
                else -> false
            }
            if (ok) return done(svc, "سحبت")
        }
        if (has(n, "اضغط مطولا", "ضغطه طويله", "long press")) { svc.gesture(w / 2, h / 2, w / 2, h / 2, 900); return done(svc, "ضغطة طويلة") }
        if (has(n, "اضغط في المنتصف", "اضغط بالمنتصف", "tap center", "tap")) { svc.gesture(w / 2, h / 2, w / 2, h / 2, 60); return done(svc, "ضغطت") }

        if (n == "انسخ" || n == "copy") return nodeAct(svc, AccessibilityNodeInfo.ACTION_COPY, "نسخت")
        if (n == "الصق" || n == "paste") return nodeAct(svc, AccessibilityNodeInfo.ACTION_PASTE, "لصقت")
        if (n == "قص" || n == "cut") return nodeAct(svc, AccessibilityNodeInfo.ACTION_CUT, "قصصت")
        if (n == "حدد الكل" || n == "select all") {
            val f = focused(svc) ?: return "✗ لا يوجد حقل نص نشط"
            val b = android.os.Bundle()
            b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, f.text?.length ?: 0)
            f.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b)
            return done(svc, "حددت الكل")
        }
        if (has(n, "امسح النص", "clear text")) { svc.typeText(""); return done(svc, "مسحت النص") }

        if (has(n, "منبه", "alarm") && num(n) != null) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(n)!!
            var hr = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toIntOrNull() ?: 0
            if (has(n, "مساء", "عصر", "ليلا", "pm") && hr < 12) hr += 12
            val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hr % 24)
                .putExtra(AlarmClock.EXTRA_MINUTES, mi).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (launch(svc, i)) return done(svc, "ضبطت المنبه %02d:%02d".format(hr % 24, mi))
        }
        if (has(n, "مؤقت", "timer", "عداد", "countdown") && num(n) != null) {
            val mult = when { has(n, "ساعه", "hour") -> 3600; has(n, "ثانيه", "ثواني", "second", "sec") -> 1; else -> 60 }
            val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, num(n)!! * mult)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            if (launch(svc, i)) return done(svc, "ضبطت المؤقت")
        }

        if (has(n, "كاميرا", "camera") && (on || has(n, "صور", "تصوير"))) {
            val act = if (has(n, "فيديو", "video")) MediaStore.INTENT_ACTION_VIDEO_CAMERA else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA
            if (launch(svc, Intent(act))) return done(svc, "فتحت الكاميرا")
        }
        if (has(n, "اتصل", "call", "كلم")) {
            val d = n.filter { it.isDigit() || it == '+' }
            if (d.length >= 3 && launch(svc, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$d")))) return done(svc, "جهزت الاتصال بالرقم $d")
        }
        Regex("^(ابحث في يوتيوب عن|youtube search|يوتيوب ابحث عن)\\s+(.+)$").find(n)?.let {
            val q = Uri.encode(it.groupValues[2])
            if (launch(svc, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q")))) return done(svc, "أبحث في يوتيوب")
        }
        Regex("^(ابحث عن|ابحث|search for|search|google|قوقل|جوجل)\\s+(.+)$").find(n)?.let {
            val q = Uri.encode(it.groupValues[2])
            if (launch(svc, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))) return done(svc, "أبحث عن ${it.groupValues[2]}")
        }
        Regex("^(خذني الي|وجهني الي|navigate to|directions to|خريطه)\\s+(.+)$").find(n)?.let {
            val q = Uri.encode(it.groupValues[2])
            if (launch(svc, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))) return done(svc, "أفتح الخريطة")
        }
        Regex("^(افتح موقع|open site|go to|زور موقع)\\s+(\\S+)$").find(n)?.let {
            val u = it.groupValues[2].let { s -> if (s.startsWith("http")) s else "https://$s" }
            if (launch(svc, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) return done(svc, "فتحت الموقع")
        }

        if (on || off || has(n, "اعدادات", "settings", "روح الي")) {
            for ((keys, act) in pages) {
                if (has(n, *keys.toTypedArray()) && launch(svc, Intent(act))) {
                    return done(svc, "فتحت الصفحة المناسبة في الإعدادات")
                }
            }
        }

        Regex("^(افتح|شغل|ابدا|روح الي|open|launch|start|run)\\s+(تطبيق |برنامج |app )?(.+)$").find(n)?.let {
            val name = it.groupValues[3].trim()
            val cands = listOfNotNull(name, alias[name], alias[name.removePrefix("ال")], name.removePrefix("ال")).distinct()
            for (c in cands) if (svc.openApp(c)) return done(svc, "فتحت $name")
        }
        return null
    }
}
