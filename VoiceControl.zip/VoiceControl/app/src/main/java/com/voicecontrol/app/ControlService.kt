package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class ControlService : AccessibilityService() {
    companion object { @Volatile var instance: ControlService? = null }

    private var eyes: EyesView? = null
    private var tts: TextToSpeech? = null

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> eyes?.setMood(Mood.SLEEPY, 0L)
                Intent.ACTION_SCREEN_ON -> eyes?.setMood(Mood.HAPPY, 3000L)
            }
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = EyesView(this)
        val p = WindowManager.LayoutParams(
            dp(240), dp(90),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(30)
        wm.addView(v, p)
        eyes = v
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        registerReceiver(screenRx, f)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        mood(Mood.HAPPY, 3000L)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) eyes?.setMood(Mood.CURIOUS, 2500L)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(screenRx) } catch (ex: Exception) {}
        eyes?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (ex: Exception) {} }
        tts?.shutdown()
        super.onDestroy()
    }

    fun mood(m: Mood, hold: Long = 2500L) { eyes?.setMood(m, hold) }

    fun toggleEyes() {
        eyes?.let { it.visibility = if (it.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    fun speak(t: String) {
        if (t.isNotBlank()) tts?.speak(t.take(3900), TextToSpeech.QUEUE_FLUSH, null, "vc")
    }

    fun global(a: Int) = performGlobalAction(a)

    fun appLabels(): List<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0).map { it.loadLabel(packageManager).toString() }.distinct()
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0)
        val q = name.trim().lowercase()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return false
        val li = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return false
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(li)
        return true
    }

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) { val r = findEditable(n.getChild(i)); if (r != null) return r }
        return null
    }

    fun typeText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) { val r = findScrollable(n.getChild(i)); if (r != null) return r }
        return null
    }

    fun scroll(down: Boolean): Boolean {
        val n = findScrollable(rootInActiveWindow) ?: return false
        return n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || sb.length > 4000) return
        val t = n.text ?: n.contentDescription
        if (t != null && t.isNotBlank()) sb.append(t).append('\n')
        for (i in 0 until n.childCount) collect(n.getChild(i), sb)
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        collect(rootInActiveWindow, sb)
        return sb.toString().trim()
    }
    fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }
}
