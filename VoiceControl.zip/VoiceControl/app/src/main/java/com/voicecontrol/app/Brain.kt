package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    fun get(c: Context, k: String): String = c.getSharedPreferences("vc", Context.MODE_PRIVATE).getString(k, "") ?: ""
    fun set(c: Context, k: String, v: String) { c.getSharedPreferences("vc", Context.MODE_PRIVATE).edit().putString(k, v).apply() }
}

object Brain {
    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.doOutput = true
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        val s = st?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code: " + s.take(200))
        return s
    }

    private fun claude(key: String, system: String, user: String): String {
        val b = JSONObject()
            .put("model", "claude-sonnet-4-6")
            .put("max_tokens", 1000)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val r = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01", "content-type" to "application/json"),
            b.toString()
        )
        return JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun gemini(key: String, system: String, user: String): String {
        val b = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", user)))))
        val r = post(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key",
            mapOf("content-type" to "application/json"),
            b.toString()
        )
        return JSONObject(r).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    fun ask(ctx: Context, system: String, user: String): String {
        val ck = Prefs.get(ctx, "claude").trim()
        val gk = Prefs.get(ctx, "gemini").trim()
        if (ck.isEmpty() && gk.isEmpty()) throw Exception("أدخل مفتاح Claude أو Gemini أولاً")
        var err = ""
        if (ck.isNotEmpty()) {
            try { return claude(ck, system, user) } catch (e: Exception) { err = "Claude: " + e.message }
        }
        if (gk.isNotEmpty()) {
            try { return gemini(gk, system, user) } catch (e: Exception) { err += " | Gemini: " + e.message }
        }
        throw Exception(err)
    }
}

object Commander {
    private const val SYS = "You control an Android phone for its owner. Convert the user's request (Arabic or English) into a JSON array of steps and output NOTHING else. " +
        "Allowed steps: {\"a\":\"open\",\"v\":\"app name as shown on device\"}, {\"a\":\"click\",\"v\":\"visible text\"}, {\"a\":\"type\",\"v\":\"text\"}, " +
        "{\"a\":\"scroll_down\"}, {\"a\":\"scroll_up\"}, {\"a\":\"back\"}, {\"a\":\"home\"}, {\"a\":\"recents\"}, {\"a\":\"notifications\"}, {\"a\":\"lock\"}, {\"a\":\"screenshot\"}, " +
        "{\"a\":\"read\"}, {\"a\":\"translate\",\"v\":\"text, or empty to translate the current screen\"}, {\"a\":\"say\",\"v\":\"short reply to the user in Arabic\"}. " +
        "For questions or chat use a single say step. Installed apps: "

    fun run(ctx: Context, raw: String): String {
        val svc = ControlService.instance ?: return "⚠ فعّل خدمة الوصول أولاً (زر تفعيل الخدمة)"
        val t = raw.trim()
        return try {
            local(ctx, svc, t) ?: plan(ctx, svc, t)
        } catch (e: Exception) {
            svc.mood(Mood.SAD)
            "✗ " + (e.message ?: "خطأ")
        }
    }

    private fun ok(s: ControlService, m: String): String { s.mood(Mood.HAPPY); return "✓ $m" }

    private fun after(t: String, vararg keys: String): String? {
        for (k in keys) if (t.startsWith(k, ignoreCase = true)) return t.substring(k.length).trim()
        return null
    }

    private fun translate(ctx: Context, svc: ControlService, v: String): String {
        val src = if (v.isBlank()) svc.readScreen() else v
        if (src.isBlank()) return "✗ لا يوجد نص للترجمة"
        val r = Brain.ask(ctx, "Translate the user's text into Arabic. Output only the translation.", src.take(6000))
        svc.speak(r)
        svc.mood(Mood.HAPPY)
        return r
    }

    private fun local(ctx: Context, svc: ControlService, t: String): String? {
        val l = t.lowercase()
        val ex: String? = when (l) {
            "رجوع", "ارجع", "back" -> { svc.global(AccessibilityService.GLOBAL_ACTION_BACK); ok(svc, "رجوع") }
            "الرئيسية", "home" -> { svc.global(AccessibilityService.GLOBAL_ACTION_HOME); ok(svc, "الرئيسية") }
            "الأحدث", "الاحدث", "recents" -> { svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS); ok(svc, "التطبيقات الأخيرة") }
            "الاشعارات", "الإشعارات", "notifications" -> { svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); ok(svc, "الإشعارات") }
            "قفل", "اقفل الشاشة", "lock" -> { svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); ok(svc, "قفل") }
            "لقطة شاشة", "screenshot" -> { svc.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); ok(svc, "لقطة شاشة") }
            "انزل", "scroll down" -> { svc.scroll(true); ok(svc, "نزول") }
            "اطلع", "scroll up" -> { svc.scroll(false); ok(svc, "صعود") }
            "اقرأ الشاشة", "read screen", "read" -> { val s = svc.readScreen(); svc.speak(s); ok(svc, s.ifBlank { "(الشاشة فارغة)" }) }
            "ترجم الشاشة", "translate screen" -> translate(ctx, svc, "")
            else -> null
        }
        if (ex != null) return ex
        Offline.run(svc, t)?.let { return it }
        after(t, "افتح ", "شغل ", "open ")?.let { if (svc.openApp(it)) return ok(svc, "فتحت $it") }
        after(t, "اكتب ", "type ")?.let { return if (svc.typeText(it)) ok(svc, "كتبت") else "✗ لا يوجد حقل نص" }
        after(t, "اضغط على ", "اضغط ", "click ")?.let { return if (svc.clickText(it)) ok(svc, "ضغطت $it") else "✗ لم أجد $it" }
        after(t, "ترجم ", "translate ")?.let { return translate(ctx, svc, it) }
        return null
    }

    private fun plan(ctx: Context, svc: ControlService, t: String): String {
        val labels = svc.appLabels().take(200).joinToString(", ")
        val reply = Brain.ask(ctx, SYS + labels, t)
        val s = reply.indexOf('[')
        val e = reply.lastIndexOf(']')
        if (s < 0 || e < s) { svc.speak(reply); return reply }
        val arr = JSONArray(reply.substring(s, e + 1))
        val log = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val v = o.optString("v")
            when (o.optString("a")) {
                "open" -> { log.append(if (svc.openApp(v)) "✓ فتح $v" else "✗ لم أجد $v").append('\n'); Thread.sleep(1500) }
                "click" -> { log.append(if (svc.clickText(v)) "✓ ضغط $v" else "✗ لم أجد $v").append('\n'); Thread.sleep(1200) }
                "type" -> { log.append(if (svc.typeText(v)) "✓ كتابة" else "✗ لا يوجد حقل").append('\n'); Thread.sleep(600) }
                "scroll_down" -> { svc.scroll(true); Thread.sleep(600) }
                "scroll_up" -> { svc.scroll(false); Thread.sleep(600) }
                "back" -> { svc.global(AccessibilityService.GLOBAL_ACTION_BACK); Thread.sleep(800) }
                "home" -> { svc.global(AccessibilityService.GLOBAL_ACTION_HOME); Thread.sleep(800) }
                "recents" -> { svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS); Thread.sleep(800) }
                "notifications" -> { svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); Thread.sleep(800) }
                "lock" -> svc.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                "screenshot" -> svc.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                "read" -> { val r = svc.readScreen(); svc.speak(r); log.append(r).append('\n') }
                "translate" -> log.append(translate(ctx, svc, v)).append('\n')
                "say" -> { svc.speak(v); log.append(v).append('\n') }
            }
        }
        svc.mood(Mood.HAPPY)
        return log.toString().trim().ifBlank { "✓ تم" }
    }
}
