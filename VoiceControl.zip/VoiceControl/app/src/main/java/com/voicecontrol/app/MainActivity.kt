package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Intent
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class HexView(c: android.content.Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF00E5FF.toInt() }
    private var a = 0f

    private fun hex(cx: Float, cy: Float, r: Float, deg: Float): Path {
        val path = Path()
        for (i in 0..5) {
            val ang = Math.toRadians((deg + i * 60).toDouble())
            val x = cx + r * cos(ang).toFloat()
            val y = cy + r * sin(ang).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return path
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) * 0.45f
        a += 0.6f
        for (k in 0..2) {
            p.alpha = 255 - k * 70
            cv.drawPath(hex(cx, cy, r * (1 - k * 0.22f), a * (if (k % 2 == 0) 1 else -1) + k * 10), p)
        }
        p.alpha = 255
        val s = Path()
        s.moveTo(cx, cy - r * 0.35f)
        s.lineTo(cx + r * 0.28f, cy - r * 0.22f)
        s.lineTo(cx + r * 0.28f, cy + r * 0.05f)
        s.quadTo(cx + r * 0.2f, cy + r * 0.3f, cx, cy + r * 0.38f)
        s.quadTo(cx - r * 0.2f, cy + r * 0.3f, cx - r * 0.28f, cy + r * 0.05f)
        s.lineTo(cx - r * 0.28f, cy - r * 0.22f)
        s.close()
        cv.drawPath(s, p)
        cv.drawLine(cx - r * 0.12f, cy + r * 0.02f, cx - r * 0.03f, cy + r * 0.12f, p)
        cv.drawLine(cx - r * 0.03f, cy + r * 0.12f, cx + r * 0.14f, cy - r * 0.1f, p)
        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var cmd: EditText
    private lateinit var status: TextView
    private val cyan = 0xFF00E5FF.toInt()

    private fun dp(x: Int) = (x * Resources.getSystem().displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setTextColor(cyan)
        val g = GradientDrawable()
        g.setColor(0x99001E2B.toInt())
        g.setStroke(dp(1), cyan)
        g.cornerRadius = dp(12).toFloat()
        b.background = g
        b.setOnClickListener { f() }
        return b
    }

    private fun row(vararg bs: Button): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (b in bs) r.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return r
    }

    private fun field(hint: String, key: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(0x8800E5FF.toInt())
        e.setTextColor(0xFFFFFFFF.toInt())
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.setText(Prefs.get(this, key))
        return e
    }

    private fun show(s: String) { out.text = s }

    private fun runCmd(t: String) {
        if (t.isBlank()) return
        show("▶ $t …")
        Thread {
            val r = Commander.run(this, t)
            runOnUiThread { show(r) }
        }.start()
    }

    private fun g(a: Int) {
        val s = ControlService.instance
        if (s == null) show("⚠ فعّل خدمة الوصول أولاً") else s.global(a)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val scrim = View(this)
        scrim.setBackgroundColor(0xB0000814.toInt())
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(40), dp(16), dp(24))

        val title = TextView(this)
        title.text = "المساعد الذكي — مركز التحكم"
        title.setTextColor(cyan)
        title.textSize = 22f
        title.gravity = Gravity.CENTER
        col.addView(title)
        col.addView(HexView(this), LinearLayout.LayoutParams(-1, dp(150)))

        status = TextView(this)
        status.setTextColor(0xFFFFFFFF.toInt())
        status.gravity = Gravity.CENTER
        col.addView(status)

        val ck = field("مفتاح Claude (اختياري)", "claude")
        val gk = field("مفتاح Gemini المجاني (احتياطي)", "gemini")
        col.addView(ck)
        col.addView(gk)
        col.addView(btn("حفظ المفاتيح") {
            Prefs.set(this, "claude", ck.text.toString())
            Prefs.set(this, "gemini", gk.text.toString())
            show("✓ تم الحفظ")
        })

        cmd = EditText(this)
        cmd.hint = "اكتب أمرك: افتح يوتيوب / اقرأ الشاشة / ترجم الشاشة …"
        cmd.setHintTextColor(0x8800E5FF.toInt())
        cmd.setTextColor(0xFFFFFFFF.toInt())
        col.addView(cmd)
        col.addView(row(
            btn("تنفيذ") { runCmd(cmd.text.toString()) },
            btn("🎤 صوت") {
                try {
                    startActivityForResult(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar"), 1)
                } catch (e: Exception) { show("✗ التعرف على الصوت غير متاح") }
            }
        ))

        col.addView(row(
            btn("تفعيل الخدمة") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("👀 العيون") {
                val s = ControlService.instance
                if (s == null) show("⚠ فعّل الخدمة") else s.toggleEyes()
            }
        ))
        col.addView(row(
            btn("رجوع") { g(AccessibilityService.GLOBAL_ACTION_BACK) },
            btn("الرئيسية") { g(AccessibilityService.GLOBAL_ACTION_HOME) },
            btn("الأحدث") { g(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        ))
        col.addView(row(
            btn("اقرأ الشاشة") { runCmd("اقرأ الشاشة") },
            btn("ترجم الشاشة") { runCmd("ترجم الشاشة") }
        ))
        col.addView(btn("🛡 فحص الأمن السيبراني") {
            show("جارٍ الفحص …")
            Thread { val r = Security.scan(this); runOnUiThread { show(r) } }.start()
        })

        out = TextView(this)
        out.setTextColor(0xFFFFFFFF.toInt())
        out.setPadding(dp(8), dp(16), dp(8), dp(8))
        out.setTextIsSelectable(true)
        col.addView(out)

        val sv = ScrollView(this)
        sv.addView(col)
        root.addView(sv, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (ControlService.instance != null) "الخدمة: ✓ تعمل" else "الخدمة: ✗ غير مفعّلة — اضغط «تفعيل الخدمة»"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == 1 && rc == RESULT_OK) {
            val t = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) { cmd.setText(t); runCmd(t) }
        }
    }
}
