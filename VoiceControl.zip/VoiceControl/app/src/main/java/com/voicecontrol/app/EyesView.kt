package com.voicecontrol.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.random.Random

enum class Mood(val color: Int) {
    NEUTRAL(0xFF00E5FF.toInt()), HAPPY(0xFF00E676.toInt()), SAD(0xFF448AFF.toInt()),
    ANGRY(0xFFFF1744.toInt()), SLEEPY(0xFF7C4DFF.toInt()), CURIOUS(0xFFFFEA00.toInt())
}

class EyesView(ctx: Context) : View(ctx) {
    private var mood = Mood.NEUTRAL
    private var lx = 0f; private var ly = 0f
    private var tx = 0f; private var ty = 0f
    private var blink = 0f
    private var nextLook = 0L; private var nextBlink = 0L; private var blinkStart = 0L
    private var revertAt = 0L
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF5FFFF.toInt() }
    private val iris = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pupil = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF000000.toInt() }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f }

    fun setMood(m: Mood, holdMs: Long) {
        mood = m
        revertAt = if (holdMs > 0) SystemClock.uptimeMillis() + holdMs else 0L
        postInvalidate()
    }

    private fun step(now: Long) {
        if (revertAt > 0 && now > revertAt) { mood = Mood.NEUTRAL; revertAt = 0L }
        if (now > nextLook) {
            tx = Random.nextFloat() * 2 - 1
            ty = (Random.nextFloat() * 2 - 1) * 0.6f
            nextLook = now + (if (mood == Mood.CURIOUS) 450L else 1400L) + Random.nextLong(1500L)
        }
        lx += (tx - lx) * 0.12f
        ly += (ty - ly) * 0.12f
        if (blinkStart == 0L && now > nextBlink) blinkStart = now
        if (blinkStart != 0L) {
            val t = (now - blinkStart) / 160f
            if (t >= 1f) { blink = 0f; blinkStart = 0L; nextBlink = now + 2500L + Random.nextLong(3000L) }
            else blink = 1f - abs(2 * t - 1)
        }
    }

    override fun onDraw(canvas: Canvas) {
        step(SystemClock.uptimeMillis())
        val r = height * 0.42f
        val cy = height / 2f
        drawEye(canvas, width * 0.28f, cy, r, true)
        drawEye(canvas, width * 0.72f, cy, r, false)
        postInvalidateOnAnimation()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, r: Float, left: Boolean) {
        val eye = Path().apply { addOval(RectF(cx - r, cy - r, cx + r, cy + r), Path.Direction.CW) }
        val lid = Path()
        val e = 3f
        when (mood) {
            Mood.ANGRY -> if (left) {
                lid.moveTo(cx - r - e, cy - r - e); lid.lineTo(cx + r + e, cy - r - e); lid.lineTo(cx + r + e, cy + r * 0.25f)
            } else {
                lid.moveTo(cx + r + e, cy - r - e); lid.lineTo(cx - r - e, cy - r - e); lid.lineTo(cx - r - e, cy + r * 0.25f)
            }
            Mood.SAD -> if (left) {
                lid.moveTo(cx - r - e, cy - r - e); lid.lineTo(cx + r + e, cy - r - e); lid.lineTo(cx - r - e, cy + r * 0.25f)
            } else {
                lid.moveTo(cx + r + e, cy - r - e); lid.lineTo(cx - r - e, cy - r - e); lid.lineTo(cx + r + e, cy + r * 0.25f)
            }
            Mood.HAPPY -> lid.addRect(cx - r - e, cy + r * 0.3f, cx + r + e, cy + r + e, Path.Direction.CW)
            Mood.SLEEPY -> lid.addRect(cx - r - e, cy - r - e, cx + r + e, cy - r * 0.1f, Path.Direction.CW)
            else -> {}
        }
        lid.close()
        if (blink > 0f) {
            lid.addRect(cx - r - e, cy - r - e, cx + r + e, cy - r + r * blink, Path.Direction.CW)
            lid.addRect(cx - r - e, cy + r - r * blink, cx + r + e, cy + r + e, Path.Direction.CW)
        }
        c.save()
        c.clipPath(eye)
        c.clipOutPath(lid)
        c.drawPath(eye, white)
        val pr = if (mood == Mood.CURIOUS) 0.72f else 0.62f
        val px = cx + lx * r * 0.35f
        val py = cy + ly * r * 0.35f
        iris.color = mood.color
        c.drawCircle(px, py, r * pr, iris)
        c.drawCircle(px, py, r * pr * 0.5f, pupil)
        c.drawCircle(px - r * 0.15f, py - r * 0.18f, r * 0.1f, shine)
        c.restore()
        ring.color = mood.color
        c.drawPath(eye, ring)
    }
}
